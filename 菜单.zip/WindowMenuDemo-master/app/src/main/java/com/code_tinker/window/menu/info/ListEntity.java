package com.code_tinker.window.menu.info;

/**
 * Created by mj
 * on 2016/10/28.
 */
public class ListEntity {

    public String avatarUrl;
    public String name;
    public String date;
    public String content;
    public String descUrl;
    public int layoutType=0;

}
