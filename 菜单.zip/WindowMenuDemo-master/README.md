# WindowMenuDemo
Android仿Qzone底部导航栏加号弹出菜单


![](http://upload-images.jianshu.io/upload_images/3093487-a2fe688c71050c1a.gif?imageMogr2/auto-orient/strip)


<a href="http://blog.csdn.net/mj_air/article/details/52957721">csdn</a>

<a href="http://www.jianshu.com/p/65fe71f7f651">简书</a>
