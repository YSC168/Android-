package com.maning.mnimagebrowser;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityOptionsCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import com.maning.imagebrowserlibrary.MNImageBrowser;
import com.maning.imagebrowserlibrary.MNImageBrowserActivity;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import com.bumptech.glide.*;

public class MainActivity extends AppCompatActivity {

    protected GridView gvImages;

    private ArrayList<String> sourceImageList;

    private Context context;

    public int ViewPagerTransformType =  MNImageBrowserActivity.ViewPagerTransform_ZoomOutSlide;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;

        gvImages = (GridView) findViewById(R.id.gv_images);


        sourceImageList = new ArrayList<>();
        sourceImageList.add("http://img01.sogoucdn.com/app/a/100520146/0303fb607eff3419c1ce6fc46e29ff7b");
        sourceImageList.add("http://img02.sogoucdn.com/app/a/100520146/b95846d9de145cc811465df2693a7250");
        sourceImageList.add( "http://img02.sogoucdn.com/app/a/100520146/2c0e80d10d45e943575e812ff6e4e350");
        sourceImageList.add("http://img01.sogoucdn.com/app/a/100520146/7b05d4fb82c54ed51dcb2e997f884fd3");
        sourceImageList.add("http://img04.sogoucdn.com/app/a/100520146/0a4e7d1aa713b45f4ab1865666ee4164");
        sourceImageList.add("http://img03.sogoucdn.com/app/a/100520146/86fdcb43d06c24ec662e089436b80563");
        sourceImageList.add("http://img03.sogoucdn.com/app/a/100520146/06b236b353cee21c483881bec1007655");
        sourceImageList.add("http://img04.sogoucdn.com/app/a/100520146/3235f69fac8f46c054a50a257bd5baee");
        sourceImageList.add("http://img01.sogoucdn.com/app/a/100520146/fa3da91e6a83c98f4b9078408e97d2b3");
        sourceImageList.add("http://img04.sogoucdn.com/app/a/100520146/f2d92303598b6e55f55460b74dc0581b");
        sourceImageList.add("http://img04.sogoucdn.com/app/a/100520146/0204f572352e553e488cd19002f1fa00");
        sourceImageList.add("http://img02.sogoucdn.com/app/a/100520146/48f6886a77088f25f9d3d0f819728142");
   
        gvImages.setAdapter(new NineGridAdapter());
    }

    private class NineGridAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return sourceImageList.size();
        }

        @Override
        public Object getItem(int position) {
            return sourceImageList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup viewGroup) {
            final ViewHolder viewHolder;
            if (convertView == null) {
                viewHolder = new ViewHolder();
                convertView = LayoutInflater.from(context).inflate(R.layout.image_item, null);
                viewHolder.imageView = (ImageView) convertView.findViewById(R.id.imageView);
                convertView.setTag(viewHolder);
            } else {
                viewHolder = (ViewHolder) convertView.getTag();
            }
			Glide.with(context).load(sourceImageList.get(position)).into(viewHolder.imageView);

         //   Picasso.with(context).load(sourceImageList.get(position)).into(viewHolder.imageView);

            viewHolder.imageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    MNImageBrowser.showImageBrowser(context, viewHolder.imageView, position, ViewPagerTransformType, sourceImageList);
                }
            });


            return convertView;
        }

        public final class ViewHolder {
            ImageView imageView;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_01:
                
                break;
            case R.id.menu_02:
                
                break;
      
        }
        return super.onOptionsItemSelected(item);
    }

}
